"use client";

import { useState } from "react";

export function LeadEditor({ lead }: { lead: any }) {
  const [form, setForm] = useState({
    timelineMonths: lead.timelineMonths ?? "",
    budgetMin: lead.budgetMin ?? "",
    budgetMax: lead.budgetMax ?? "",
    financingStatus: lead.financingStatus ?? "",
    motivation: lead.motivation ?? "",
    notes: lead.notes ?? "",
    expectedGci: lead.expectedGci ?? 0,
    protectedByAi: lead.protectedByAi ?? false,
    stage: lead.stage,
    logCall: false
  });
  const [saving, setSaving] = useState(false);

  function set(key: string, value: any) { setForm((prev) => ({ ...prev, [key]: value })); }
  async function save(extra: Record<string, any> = {}) {
    setSaving(true);
    await fetch(`/api/leads/${lead.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...form, ...extra }) });
    setSaving(false);
    window.location.reload();
  }

  return (
    <div className="card">
      <div className="section-head"><h2>Buyer Understanding</h2><button className="btn primary" onClick={() => save()} disabled={saving}>{saving ? "Saving…" : "Save"}</button></div>
      <div className="form-grid">
        <div className="field"><label>Timeline (months)</label><input value={form.timelineMonths} onChange={(e) => set("timelineMonths", e.target.value)} /></div>
        <div className="field"><label>Expected GCI</label><input value={form.expectedGci} onChange={(e) => set("expectedGci", e.target.value)} /></div>
        <div className="field"><label>Budget minimum</label><input value={form.budgetMin} onChange={(e) => set("budgetMin", e.target.value)} /></div>
        <div className="field"><label>Budget maximum</label><input value={form.budgetMax} onChange={(e) => set("budgetMax", e.target.value)} /></div>
        <div className="field"><label>Financing</label><input value={form.financingStatus} onChange={(e) => set("financingStatus", e.target.value)} placeholder="Cash, pre-approved, needs lender…" /></div>
        <div className="field"><label>Stage</label><select value={form.stage} onChange={(e) => set("stage", e.target.value)}>{["NEW","ATTEMPTING_CONTACT","CONNECTED","NURTURE","ACTIVE_SEARCH","TOURING","OFFER","UNDER_CONTRACT","CLOSED","LOST"].map((s)=><option key={s}>{s}</option>)}</select></div>
        <div className="field full"><label>Motivation</label><textarea rows={3} value={form.motivation} onChange={(e) => set("motivation", e.target.value)} /></div>
        <div className="field full"><label>Agent notes</label><textarea rows={5} value={form.notes} onChange={(e) => set("notes", e.target.value)} /></div>
      </div>
      <div className="actions" style={{marginTop:14}}>
        <button className="btn" onClick={() => save({ logCall: true })}>Log Phone Attempt</button>
        <button className="btn accent" onClick={() => save({ protectedByAi: !form.protectedByAi })}>{form.protectedByAi ? "Disable AI Protection" : "Protect This Lead"}</button>
      </div>
    </div>
  );
}
