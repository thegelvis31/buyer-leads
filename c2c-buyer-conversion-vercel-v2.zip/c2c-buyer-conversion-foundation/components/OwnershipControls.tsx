"use client";
import { useState } from "react";

export function OwnershipControls({ lead, agents }: { lead: any; agents: any[] }) {
  const [toAgentId, setToAgentId] = useState(agents.find(a => a.id !== lead.currentOwnerId)?.id || "");
  const [reason, setReason] = useState("Workload balancing");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const owner = agents.find(a => a.id === lead.currentOwnerId);
  async function transfer() {
    if (!toAgentId || !reason) return;
    setSaving(true);
    await fetch(`/api/leads/${lead.id}/transfer`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ toAgentId, reason, notes, transferredBy: "CRM user" }) });
    window.location.reload();
  }
  async function togglePause() {
    if (!owner) return;
    setSaving(true);
    const pause = owner.availabilityStatus !== "PAUSED";
    await fetch(`/api/agents/${owner.id}/availability`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: pause ? "PAUSED" : "ACTIVE", reason: pause ? "Vacation / out of office" : null }) });
    window.location.reload();
  }
  return <div className="card stack">
    <div className="section-head"><h2>Ownership & Availability</h2><span className="badge">Audit ready</span></div>
    <div className="notice"><strong>Current owner:</strong> {owner?.name || lead.assignedAgent || "Unassigned"}<br/><span className={owner?.availabilityStatus === "PAUSED" ? "danger" : "success"}>{owner?.availabilityStatus === "PAUSED" ? `Paused${owner.pauseReason ? ` · ${owner.pauseReason}` : ""}` : "Accepting new leads"}</span></div>
    <div className="field"><label>Transfer to</label><select value={toAgentId} onChange={e=>setToAgentId(e.target.value)}>{agents.filter(a=>a.id!==lead.currentOwnerId).map(a=><option key={a.id} value={a.id}>{a.name} · {a.role} · {a.availabilityStatus}</option>)}</select></div>
    <div className="field"><label>Reason</label><select value={reason} onChange={e=>setReason(e.target.value)}>{["Workload balancing","Better area/community fit","Language match","Specialty match","Agent unavailable","Client request","Team reassignment","Other"].map(r=><option key={r}>{r}</option>)}</select></div>
    <div className="field"><label>Transfer notes</label><textarea rows={3} value={notes} onChange={e=>setNotes(e.target.value)} /></div>
    <div className="actions"><button className="btn primary" disabled={saving || !toAgentId} onClick={transfer}>Transfer Lead</button><button className="btn" disabled={saving || !owner} onClick={togglePause}>{owner?.availabilityStatus === "PAUSED" ? "Resume New Leads" : "Pause New Leads"}</button></div>
    <div className="muted">Pausing stops new lead routing; existing leads stay assigned and AI protection continues.</div>
  </div>;
}
