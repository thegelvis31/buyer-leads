"use client";

import { useState } from "react";

export function ImportLeads() {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function upload(file: File) {
    setBusy(true);
    setMessage("");
    const data = new FormData();
    data.append("file", file);
    const res = await fetch("/api/leads/import", { method: "POST", body: data });
    const result = await res.json();
    setBusy(false);
    setMessage(res.ok ? `Imported ${result.imported} leads.` : result.error || "Import failed.");
    if (res.ok) window.location.reload();
  }

  return (
    <div>
      <label className="btn" style={{ display: "inline-block" }}>
        {busy ? "Importing…" : "Import Sierra CSV"}
        <input
          hidden
          type="file"
          accept=".csv,text/csv"
          onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])}
        />
      </label>
      {message && <div className="muted" style={{ marginTop: 8 }}>{message}</div>}
    </div>
  );
}
