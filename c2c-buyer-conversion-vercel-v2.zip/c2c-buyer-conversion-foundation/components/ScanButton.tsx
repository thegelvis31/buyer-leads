"use client";

import { useState } from "react";

export function ScanButton() {
  const [busy, setBusy] = useState(false);
  async function scan() {
    setBusy(true);
    await fetch("/api/leads/scan", { method: "POST" });
    setBusy(false);
    window.location.reload();
  }
  return <button className="btn accent" onClick={scan} disabled={busy}>{busy ? "Scanning database…" : "Scan Database Now"}</button>;
}
