import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { ImportLeads } from "@/components/ImportLeads";
import { ScanButton } from "@/components/ScanButton";

export const dynamic = "force-dynamic";

function money(value: number) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(value);
}

export default async function HomePage() {
  const leads = await prisma.lead.findMany({ orderBy: [{ buyingProbability: "desc" }, { lastActivityAt: "desc" }], take: 50 });
  const hot = leads.filter((l) => l.buyingProbability >= 60);
  const atRisk = leads.filter((l) => l.ghostRisk >= 60);
  const protectedCount = leads.filter((l) => l.protectedByAi).length;
  const pipelineGci = leads.reduce((sum, l) => sum + l.expectedGci, 0);

  return (
    <>
      <div className="topbar">
        <div className="title">
          <h1>Buyer Opportunity Center</h1>
          <p>Work the buyers most likely to convert. Protect everyone else from falling through the cracks.</p>
        </div>
        <div className="actions"><ImportLeads /><ScanButton /></div>
      </div>

      <section className="grid metrics">
        <div className="card metric"><div className="label">Potential GCI</div><div className="value">{money(pipelineGci)}</div><div className="sub">Across imported buyer leads</div></div>
        <div className="card metric"><div className="label">High-Intent Buyers</div><div className="value">{hot.length}</div><div className="sub">60%+ buying probability</div></div>
        <div className="card metric"><div className="label">Leads at Risk</div><div className="value">{atRisk.length}</div><div className="sub">High ghost risk or missing follow-up</div></div>
        <div className="card metric"><div className="label">AI Protected</div><div className="value">{protectedCount}</div><div className="sub">Automated follow-up safety net</div></div>
      </section>

      <section className="content-grid">
        <div className="card">
          <div className="section-head"><h2>Who should you work now?</h2><span className="muted">Ranked by conversion opportunity</span></div>
          <div className="lead-list">
            {leads.length === 0 && <div className="muted">Import your first Sierra CSV to begin.</div>}
            {leads.map((lead) => (
              <Link key={lead.id} href={`/leads/${lead.id}`} className="lead-row">
                <div><div className="lead-name">{lead.firstName} {lead.lastName}</div><div className="muted">{lead.source || "Unknown source"}{lead.sourceDetail ? ` · ${lead.sourceDetail}` : ""}</div></div>
                <div><div className="score">{lead.buyingProbability}%</div><div className="muted">Buying probability</div></div>
                <div><span className={`badge ${lead.temperature.toLowerCase()}`}>{lead.temperature}</span><div className="muted" style={{marginTop:6}}>Ghost risk {lead.ghostRisk}%</div></div>
                <div><strong>{lead.nextBestAction}</strong><div className="muted">Expected GCI {money(lead.expectedGci)}</div></div>
                <div className="btn primary">Open</div>
              </Link>
            ))}
          </div>
        </div>

        <aside className="card scan-box">
          <div className="section-head"><h2>Conversion Scan</h2><span className="badge">2× daily</span></div>
          <p>The first version scores behavior, database completeness, contact history, timeline, and risk. Later, plug in IDX, Twilio, SendGrid, and AI note analysis.</p>
          <div className="reason-list">
            <div className="reason">Hot buyer + no recent human contact → critical escalation</div>
            <div className="reason">Return visits, saved homes, and replies increase priority</div>
            <div className="reason">Missing timeline, budget, financing, or motivation lowers profile confidence</div>
            <div className="reason">Every scan saves a score snapshot for pattern tracking</div>
          </div>
        </aside>
      </section>
    </>
  );
}
