import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const body = await request.json();
  const lead = await prisma.lead.update({
    where: { id },
    data: {
      timelineMonths: body.timelineMonths === "" ? null : Number(body.timelineMonths),
      budgetMin: body.budgetMin === "" ? null : Number(body.budgetMin),
      budgetMax: body.budgetMax === "" ? null : Number(body.budgetMax),
      financingStatus: body.financingStatus || null,
      motivation: body.motivation || null,
      notes: body.notes || null,
      expectedGci: Number(body.expectedGci || 0),
      protectedByAi: Boolean(body.protectedByAi),
      lastContactAt: body.logCall ? new Date() : undefined,
      stage: body.stage,
      events: body.logCall ? { create: { type: "CALL_ATTEMPT", channel: "phone", summary: "Agent logged a phone attempt" } } : undefined
    }
  });
  return NextResponse.json(lead);
}
