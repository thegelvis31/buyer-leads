import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const body = await request.json();
  if (!body.toAgentId || !body.reason) return NextResponse.json({ error: "Agent and reason are required" }, { status: 400 });
  const lead = await prisma.lead.findUnique({ where: { id }, include: { currentOwner: true } });
  if (!lead) return NextResponse.json({ error: "Lead not found" }, { status: 404 });
  const target = await prisma.agent.findUnique({ where: { id: body.toAgentId } });
  if (!target) return NextResponse.json({ error: "Target agent not found" }, { status: 404 });
  await prisma.$transaction([
    prisma.leadTransfer.create({ data: { leadId: id, fromAgentId: lead.currentOwnerId, toAgentId: target.id, reason: body.reason, notes: body.notes || null, transferredBy: body.transferredBy || "Current user" } }),
    prisma.lead.update({ where: { id }, data: { currentOwnerId: target.id, assignedAgent: target.name, events: { create: { type: "LEAD_TRANSFERRED", summary: `Lead transferred from ${lead.currentOwner?.name || lead.assignedAgent || "Unassigned"} to ${target.name}`, metadata: { reason: body.reason, notes: body.notes || null, transferredBy: body.transferredBy || "Current user" } } } } })
  ]);
  return NextResponse.json({ ok: true });
}
