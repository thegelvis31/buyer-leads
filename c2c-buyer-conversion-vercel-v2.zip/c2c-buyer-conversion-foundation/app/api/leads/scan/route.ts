import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { scoreLead } from "@/lib/scoring";

export const runtime = "nodejs";

export async function POST() {
  const leads = await prisma.lead.findMany({ include: { events: true } });
  let scanned = 0;

  for (const lead of leads) {
    const result = scoreLead(lead);
    await prisma.lead.update({
      where: { id: lead.id },
      data: {
        buyingProbability: result.buyingProbability,
        profileConfidence: result.profileConfidence,
        relationshipHealth: result.relationshipHealth,
        ghostRisk: result.ghostRisk,
        nextBestAction: result.nextBestAction,
        temperature: result.temperature,
        events: { create: { type: "AI_SCAN", summary: result.reason } },
        scores: {
          create: {
            buyingProbability: result.buyingProbability,
            profileConfidence: result.profileConfidence,
            relationshipHealth: result.relationshipHealth,
            ghostRisk: result.ghostRisk,
            reason: result.reason
          }
        }
      }
    });
    scanned++;
  }

  return NextResponse.json({ scanned });
}
