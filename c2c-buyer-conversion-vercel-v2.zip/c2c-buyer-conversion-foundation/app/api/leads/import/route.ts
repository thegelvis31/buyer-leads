import { NextResponse } from "next/server";
import { parse } from "csv-parse/sync";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

function value(row: Record<string, string>, names: string[]) {
  for (const name of names) {
    const key = Object.keys(row).find((k) => k.trim().toLowerCase() === name.toLowerCase());
    if (key && row[key]?.trim()) return row[key].trim();
  }
  return undefined;
}

export async function POST(request: Request) {
  try {
    const data = await request.formData();
    const file = data.get("file");
    if (!(file instanceof File)) return NextResponse.json({ error: "CSV file required." }, { status: 400 });
    const text = await file.text();
    const rows = parse(text, { columns: true, skip_empty_lines: true, bom: true, relax_column_count: true }) as Record<string, string>[];

    let imported = 0;
    for (const row of rows.slice(0, 500)) {
      const firstName = value(row, ["First Name", "FirstName", "first_name", "Name"]) || "Unknown";
      const lastName = value(row, ["Last Name", "LastName", "last_name"]);
      const expectedGciRaw = value(row, ["Expected GCI", "GCI", "expected_gci"]);
      await prisma.lead.create({
        data: {
          firstName,
          lastName,
          email: value(row, ["Email", "Primary Email", "email_address"]),
          phone: value(row, ["Phone", "Mobile", "Primary Phone", "phone_number"]),
          source: value(row, ["Source", "Lead Source", "lead_source"]),
          sourceDetail: value(row, ["Source Detail", "Sub Source", "Lead Type"]),
          campaign: value(row, ["Campaign", "Campaign Name"]),
          keyword: value(row, ["Keyword", "Search Term"]),
          landingPage: value(row, ["Landing Page", "Landing URL", "Registration Page"]),
          originalCommunity: value(row, ["Community", "Original Community"]),
          notes: value(row, ["Notes", "Agent Notes", "Description"]),
          expectedGci: expectedGciRaw ? Number(expectedGciRaw.replace(/[^0-9.-]+/g, "")) || 0 : 0,
          lastActivityAt: new Date(),
          events: {
            create: { type: "LEAD_CREATED", summary: "Lead imported from Sierra CSV", metadata: { originalRow: row } }
          }
        }
      });
      imported++;
    }

    return NextResponse.json({ imported });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Unable to import CSV. Confirm the file has a header row." }, { status: 500 });
  }
}
