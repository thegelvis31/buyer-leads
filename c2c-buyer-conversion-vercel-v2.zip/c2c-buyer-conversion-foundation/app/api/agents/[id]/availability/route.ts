import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const body = await request.json();
  const paused = body.status === "PAUSED";
  const agent = await prisma.agent.update({ where: { id }, data: { availabilityStatus: paused ? "PAUSED" : "ACTIVE", pauseReason: paused ? body.reason || "Unavailable" : null, pausedAt: paused ? new Date() : null, resumeAt: paused && body.resumeAt ? new Date(body.resumeAt) : null } });
  return NextResponse.json(agent);
}
