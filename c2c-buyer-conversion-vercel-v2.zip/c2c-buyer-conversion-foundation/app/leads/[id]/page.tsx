import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { LeadEditor } from "@/components/LeadEditor";
import { OwnershipControls } from "@/components/OwnershipControls";

export const dynamic = "force-dynamic";

export default async function LeadPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [lead, agents] = await Promise.all([
    prisma.lead.findUnique({ where: { id }, include: { currentOwner: true, transfers: { orderBy: { transferredAt: "desc" }, take: 10 }, events: { orderBy: { occurredAt: "desc" }, take: 30 }, scores: { orderBy: { createdAt: "desc" }, take: 10 } } }),
    prisma.agent.findMany({ orderBy: { name: "asc" } })
  ]);
  if (!lead) notFound();

  return (
    <>
      <div className="topbar">
        <div className="title"><Link className="muted" href="/">← Opportunity Center</Link><h1>{lead.firstName} {lead.lastName}</h1><p>{lead.source || "Unknown source"} · {lead.landingPage || "No landing page captured"}</p></div>
        <div className="actions"><button className="btn primary">Call {lead.phone || "lead"}</button><button className="btn">Text</button><button className="btn">Email</button></div>
      </div>

      <section className="grid metrics">
        <div className="card metric"><div className="label">Buying Probability</div><div className="value">{lead.buyingProbability}%</div><div className="sub">{lead.nextBestAction}</div></div>
        <div className="card metric"><div className="label">Profile Confidence</div><div className="value">{lead.profileConfidence}%</div><div className="sub">How well the buyer is understood</div></div>
        <div className="card metric"><div className="label">Relationship Health</div><div className="value">{lead.relationshipHealth}%</div><div className="sub">Human contact and responsiveness</div></div>
        <div className="card metric"><div className="label">Ghost Risk</div><div className="value">{lead.ghostRisk}%</div><div className="sub">AI protection {lead.protectedByAi ? "active" : "inactive"}</div></div>
      </section>

      <section className="content-grid">
        <div className="stack"><LeadEditor lead={lead} /><OwnershipControls lead={lead} agents={agents} /></div>
        <div className="card">
          <div className="section-head"><h2>Revenue Journey</h2><span className="badge">{lead.temperature}</span></div>
          <div className="timeline">
            {lead.events.map((event) => <div className="timeline-item" key={event.id}><strong>{event.summary}</strong><div className="muted">{new Date(event.occurredAt).toLocaleString()} · {event.type}</div></div>)}
          </div>
        </div>
      </section>
    </>
  );
}
