import "./globals.css";

export const metadata = {
  title: "Buyer Conversion Center",
  description: "Embedded buyer lead conversion module for an existing CRM"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body><main className="main">{children}</main></body>
    </html>
  );
}
