import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();
async function main() {
  await prisma.leadTransfer.deleteMany();
  await prisma.leadEvent.deleteMany();
  await prisma.leadScoreSnapshot.deleteMany();
  await prisma.lead.deleteMany();
  await prisma.agent.deleteMany();
  const frank = await prisma.agent.create({ data: { name: "Frank Harris", email: "frank@harrisluxuryrealty.com", role: "BROKER" } });
  await prisma.agent.createMany({ data: [
    { name: "Priya Shah", email: "priya@example.com", role: "AGENT" },
    { name: "Dana Reyes", email: "dana@example.com", role: "TEAM_LEAD" }
  ]});
  await prisma.lead.create({ data: { firstName: "Palm Grove", lastName: "YouTube Buyer", phone: "941-555-0101", email: "buyer@example.com", source: "YouTube", sourceDetail: "Palm Grove Community Video", originalCommunity: "Palm Grove", landingPage: "YouTube video call-in", currentOwnerId: frank.id, assignedAgent: frank.name, stage: "TOURING", temperature: "HOT", buyingProbability: 78, profileConfidence: 62, relationshipHealth: 74, ghostRisk: 18, expectedGci: 18000, timelineMonths: 1, notes: "Found Frank through the Palm Grove YouTube video. Met July 11, 2026. Likely new-construction contract.", lastContactAt: new Date("2026-07-11T14:00:00-04:00"), lastActivityAt: new Date(), events: { create: [
    { type: "LEAD_CREATED", summary: "Buyer called from Palm Grove YouTube video", occurredAt: new Date("2026-06-20T10:00:00-04:00") },
    { type: "CALL_CONNECTED", summary: "Initial buyer conversation", occurredAt: new Date("2026-06-20T10:05:00-04:00") },
    { type: "TOUR_COMPLETED", summary: "Met buyers at Palm Grove", occurredAt: new Date("2026-07-11T14:00:00-04:00") }
  ] } } });
}
main().finally(() => prisma.$disconnect());
