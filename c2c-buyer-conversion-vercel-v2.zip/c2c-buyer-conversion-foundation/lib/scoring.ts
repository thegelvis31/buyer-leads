import type { Lead, LeadEvent } from "@prisma/client";

type ScorableLead = Lead & { events: LeadEvent[] };

const clamp = (value: number) => Math.max(0, Math.min(100, Math.round(value)));

export function scoreLead(lead: ScorableLead) {
  const now = Date.now();
  const recent = lead.events.filter((e) => now - new Date(e.occurredAt).getTime() <= 7 * 86400000);
  const last48h = recent.filter((e) => now - new Date(e.occurredAt).getTime() <= 2 * 86400000);

  let buying = 18;
  let confidence = 10;
  let relationship = 10;
  let ghost = 35;
  const reasons: string[] = [];

  const count = (type: string) => recent.filter((e) => e.type === type).length;
  const count48 = (type: string) => last48h.filter((e) => e.type === type).length;

  const propertyViews = count("PROPERTY_VIEWED");
  const saved = count("PROPERTY_SAVED");
  const visits = count("SITE_VISIT");
  const replies = count("TEXT_REPLIED") + count("CALL_CONNECTED") + count("EMAIL_CLICKED");

  if (propertyViews > 0) {
    buying += Math.min(22, propertyViews * 2);
    reasons.push(`${propertyViews} property views in 7 days`);
  }
  if (saved > 0) {
    buying += Math.min(18, saved * 6);
    reasons.push(`${saved} saved properties`);
  }
  if (visits > 1) {
    buying += Math.min(15, visits * 3);
    reasons.push(`${visits} return visits`);
  }
  if (count48("COMMUNITY_VIEWED") > 1) {
    buying += 7;
    reasons.push("Comparing communities in the last 48 hours");
  }
  if (replies > 0) {
    buying += Math.min(12, replies * 4);
    relationship += Math.min(28, replies * 8);
    ghost -= Math.min(25, replies * 7);
    reasons.push("Recent communication engagement");
  }
  if (lead.timelineMonths !== null) {
    confidence += 15;
    if (lead.timelineMonths <= 3) buying += 16;
    else if (lead.timelineMonths <= 6) buying += 8;
  }
  if (lead.budgetMax || lead.budgetMin) confidence += 15;
  if (lead.financingStatus) confidence += 15;
  if (lead.motivation) confidence += 15;
  if (lead.notes) confidence += 10;
  if (lead.lastContactAt) {
    relationship += 12;
    const days = (now - new Date(lead.lastContactAt).getTime()) / 86400000;
    if (days > 14 && buying > 55) {
      ghost += 20;
      reasons.push("High intent but no human contact in 14+ days");
    }
  }
  if (lead.protectedByAi) ghost -= 10;

  buying = clamp(buying);
  confidence = clamp(confidence);
  relationship = clamp(relationship);
  ghost = clamp(ghost);

  let nextBestAction = "Call now";
  if (!lead.phone && lead.email) nextBestAction = "Send personalized email";
  else if (buying >= 75 && lead.phone) nextBestAction = "Call immediately";
  else if (ghost >= 65) nextBestAction = "Activate Protect This Lead";
  else if (replies === 0 && lead.phone) nextBestAction = "Make first phone attempt";
  else if (lead.nextFollowUpAt) nextBestAction = "Complete scheduled follow-up";

  const temperature = buying >= 80 ? "CRITICAL" : buying >= 60 ? "HOT" : buying >= 35 ? "WARM" : "COLD";

  return {
    buyingProbability: buying,
    profileConfidence: confidence,
    relationshipHealth: relationship,
    ghostRisk: ghost,
    nextBestAction,
    temperature,
    reason: reasons.length ? reasons.join("; ") : "Limited behavioral data available"
  } as const;
}
