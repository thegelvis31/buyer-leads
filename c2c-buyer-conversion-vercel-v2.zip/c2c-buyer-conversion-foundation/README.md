# C2C Buyer Conversion Center — Standalone Vercel Foundation

This is a standalone Next.js/PostgreSQL proof-of-concept that can be uploaded to GitHub and deployed to Vercel now. It intentionally has **no sidebar and no logo** so it can later be embedded inside the existing C2C CRM shell.

## Included
- Opportunity Queue ranked by transparent conversion scoring
- Sierra CSV import for a small pilot group
- Scan Database button and score snapshots
- Buyer intelligence page and event timeline
- Protect This Lead
- Lead transfer with required reason, notes, actor, date, and timestamp
- Agent accepting-new-leads / vacation pause foundation
- Broker, team lead, and agent roles in the schema
- Palm Grove YouTube buyer seed example with $18,000 expected GCI

## Deploy
1. Upload the unzipped contents to a new GitHub repository.
2. Create a PostgreSQL database through Neon, Supabase, or Vercel Marketplace.
3. Add `DATABASE_URL` in Vercel Project Settings → Environment Variables.
4. Locally run:
   ```bash
   npm install
   npx prisma db push
   npm run db:seed
   npm run dev
   ```
5. Import the GitHub repository into Vercel and deploy.

Vercel builds with `prisma generate && next build` automatically.

## Important limitation
This is a separate validation app because the existing production repository was not provided. It will not automatically inherit your current auth, tenants, sidebar, roles, Twilio, SendGrid, IDX, or CRM database. Use it to begin testing the first 15 leads, then merge the module into the production repo after the workflows are validated.
